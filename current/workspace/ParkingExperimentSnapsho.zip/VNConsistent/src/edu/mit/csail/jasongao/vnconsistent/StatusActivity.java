package edu.mit.csail.jasongao.vnconsistent;

import java.io.File;
import java.io.PrintWriter;

import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class StatusActivity extends Activity implements LocationListener {
	final static private String TAG = "StatusActivity";

	// UI elements
	private boolean directionButtonsEnabled = true;
	Button left, right, up, down, testcsm;
	Button releaseparking;
	Button requestparkingA, readparkingA;
	Button requestparkingB, readparkingB;
	Button requestparkingC, readparkingC;
	Button cacheenable, cachedisable;
	Button setdistribution30, setdistribution60, setdistribution90;
	TextView opCountTv, successCountTv, failureCountTv;
	TextView idTv, stateTv, regionTv, leaderTv, csmTv;
	ListView msgList;
	ArrayAdapter<String> receivedMessages;

	PowerManager.WakeLock wl = null;
	LocationManager lm;

	// Logging to file
	File myLogFile;
	PrintWriter myLogWriter;

	// Mux
	Mux mux;

	/** Handle messages from various components */
	private final Handler myHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case Mux.LOG:
				receivedMessages.add((String) msg.obj);
				// Write to file
				if (myLogWriter != null) {
					myLogWriter.println((String) msg.obj);
				}
				break;
			case Mux.LOG_NODISPLAY:
				// receivedMessages.add((String) msg.obj);
				// Write to file
				if (myLogWriter != null) {
					myLogWriter.println((String) msg.obj);
				}
				break;
			case Mux.STATUS_CHANGE:
				update();
				break;
			case Mux.PARKING_CHANGE:
				updateParking((Long) msg.obj);
				break;
			}
		}
	};

	/** Log message and also display on screen */
	public void logMsg(String msg) {
		receivedMessages.add(msg);
		Log.i(TAG, msg);
	}

	/** Force an update of the screen views */
	public void update() {
		idTv.setText(String.valueOf(mux.vncDaemon.mId));
		leaderTv.setText(String.valueOf(mux.vncDaemon.leaderId));
		regionTv.setText(String.format("(%d,%d)", mux.vncDaemon.myRegion.x,
				mux.vncDaemon.myRegion.y));

		switch (mux.vncDaemon.mState) {
		case VNCDaemon.DORMANT:
			stateTv.setText("DORMANT");
			break;
		case VNCDaemon.JOINING:
			stateTv.setText("JOINING");
			break;
		case VNCDaemon.LEADER:
			stateTv.setText("LEADER");
			break;
		case VNCDaemon.NONLEADER:
			stateTv.setText("NONLEADER");
			break;
		}
	}

	/** Force an update of the parking views */
	public void updateParking(long val) {
		csmTv.setText(String.valueOf(val));
	}

	/**
	 * Android application lifecycle management
	 **/

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Buttons
		cacheenable = (Button) findViewById(R.id.cacheenable_button);
		cacheenable.setOnClickListener(cacheenable_listener);
		cachedisable = (Button) findViewById(R.id.cachedisable_button);
		cachedisable.setOnClickListener(cachedisable_listener);

		setdistribution30 = (Button) findViewById(R.id.setdistribution30_button);
		setdistribution30.setOnClickListener(setdistribution30_listener);
		setdistribution60 = (Button) findViewById(R.id.setdistribution60_button);
		setdistribution60.setOnClickListener(setdistribution60_listener);
		setdistribution90 = (Button) findViewById(R.id.setdistribution90_button);
		setdistribution90.setOnClickListener(setdistribution90_listener);

		left = (Button) findViewById(R.id.left_button);
		left.setOnClickListener(left_listener);
		right = (Button) findViewById(R.id.right_button);
		right.setOnClickListener(right_listener);
		up = (Button) findViewById(R.id.up_button);
		up.setOnClickListener(up_listener);
		down = (Button) findViewById(R.id.down_button);
		down.setOnClickListener(down_listener);

		testcsm = (Button) findViewById(R.id.testcsm_button);
		testcsm.setOnClickListener(testcsm_listener);
		releaseparking = (Button) findViewById(R.id.releaseparking_button);
		releaseparking.setOnClickListener(releaseparking_listener);

		requestparkingA = (Button) findViewById(R.id.requestparkingA_button);
		requestparkingA.setOnClickListener(requestparkingA_listener);
		readparkingA = (Button) findViewById(R.id.readparkingA_button);
		readparkingA.setOnClickListener(readparkingA_listener);

		requestparkingB = (Button) findViewById(R.id.requestparkingB_button);
		requestparkingB.setOnClickListener(requestparkingB_listener);
		readparkingB = (Button) findViewById(R.id.readparkingB_button);
		readparkingB.setOnClickListener(readparkingB_listener);

		requestparkingC = (Button) findViewById(R.id.requestparkingC_button);
		requestparkingC.setOnClickListener(requestparkingC_listener);
		readparkingC = (Button) findViewById(R.id.readparkingC_button);
		readparkingC.setOnClickListener(readparkingC_listener);

		// Text views
		opCountTv = (TextView) findViewById(R.id.opcount_tv);
		successCountTv = (TextView) findViewById(R.id.successcount_tv);
		failureCountTv = (TextView) findViewById(R.id.failurecount_tv);

		// Text views
		idTv = (TextView) findViewById(R.id.id_tv);
		stateTv = (TextView) findViewById(R.id.state_tv);
		regionTv = (TextView) findViewById(R.id.region_tv);
		leaderTv = (TextView) findViewById(R.id.leader_tv);
		csmTv = (TextView) findViewById(R.id.csm_tv);
		msgList = (ListView) findViewById(R.id.msgList);
		receivedMessages = new ArrayAdapter<String>(this, R.layout.message);
		msgList.setAdapter(receivedMessages);

		// Get a wakelock to keep everything running
		PowerManager pm = (PowerManager) getApplicationContext()
				.getSystemService(Context.POWER_SERVICE);
		wl = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK
				| PowerManager.ON_AFTER_RELEASE, TAG);
		wl.acquire();

		lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

		// Setup writing to log file on sd card
		boolean mExternalStorageAvailable = false;
		boolean mExternalStorageWriteable = false;
		String state = Environment.getExternalStorageState();
		if (Environment.MEDIA_MOUNTED.equals(state)) {
			// We can read and write the media
			mExternalStorageAvailable = mExternalStorageWriteable = true;
		} else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
			// We can only read the media
			mExternalStorageAvailable = true;
			mExternalStorageWriteable = false;
		} else {
			// Something else is wrong. It may be one of many other states, but
			// all we need to know is we can neither read nor write
			mExternalStorageAvailable = mExternalStorageWriteable = false;
		}

		if (mExternalStorageAvailable && mExternalStorageWriteable) {
			myLogFile = new File(Environment.getExternalStorageDirectory(),
					String.format("csm-%d.txt", System.currentTimeMillis()));
			try {
				myLogWriter = new PrintWriter(myLogFile);
				logMsg("*** Opened log file for writing ***");
			} catch (Exception e) {
				myLogWriter = null;
				logMsg("*** Couldn't open log file for writing ***");
			}
		}

		// Start the mux, which will start the entire VNC, CSM, etc stack
		long id = -1;
		Bundle extras = getIntent().getExtras();
		if (extras != null && extras.containsKey("id")) {
			id = Long.valueOf(extras.getString("id"));
		}
		mux = new Mux(id, myHandler);
		mux.start();

		logMsg("*** Application started ***");
	} // end OnCreate()

	/**
	 * onResume is is always called after onStart, even if userServer's not
	 * paused
	 */
	@Override
	protected void onResume() {
		super.onResume();
		// update if 1000ms have passed ( once GPS fix is acquired )
		// lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000ms, 0f,
		// this);

		// update if phone moves 5m ( once GPS fix is acquired )
		// or if 1 min has passed since last update
		lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 60000, 5f, this);
	}

	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	public void onDestroy() {
		mux.requestStop();

		myLogWriter.flush();
		myLogWriter.close();

		lm.removeUpdates(this);
		if (wl != null)
			wl.release();
		super.onDestroy();
	}

	/*** UI Callbacks for Buttons, etc. ***/
	private OnClickListener setdistribution30_listener = new OnClickListener() {
		public void onClick(View v) {
			logMsg("Set distribution to 30% reads.");
			mux.userClient.setReadWriteDistribution(0.3);
		}
	};
	private OnClickListener setdistribution60_listener = new OnClickListener() {
		public void onClick(View v) {
			logMsg("Set distribution to 60% reads.");
			mux.userClient.setReadWriteDistribution(0.6);
		}
	};
	private OnClickListener setdistribution90_listener = new OnClickListener() {
		public void onClick(View v) {
			logMsg("Set distribution to 90% reads.");
			mux.userClient.setReadWriteDistribution(0.9);
		}
	};

	private OnClickListener readparkingA_listener = new OnClickListener() {
		public void onClick(View v) {
			mux.userClient.readParking(0, 0);
		}
	};
	private OnClickListener readparkingB_listener = new OnClickListener() {
		public void onClick(View v) {
			mux.userClient.readParking(1, 0);
		}
	};
	private OnClickListener readparkingC_listener = new OnClickListener() {
		public void onClick(View v) {
			mux.userClient.readParking(2, 0);
		}
	};

	private OnClickListener requestparkingA_listener = new OnClickListener() {
		public void onClick(View v) {
			mux.userClient.requestParking(0, 0);
		}
	};
	private OnClickListener requestparkingB_listener = new OnClickListener() {
		public void onClick(View v) {
			mux.userClient.requestParking(1, 0);
		}
	};
	private OnClickListener requestparkingC_listener = new OnClickListener() {
		public void onClick(View v) {
			mux.userClient.requestParking(2, 0);
		}
	};

	private OnClickListener releaseparking_listener = new OnClickListener() {
		public void onClick(View v) {
			mux.userClient.releaseParking();
		}
	};

	private OnClickListener testcsm_listener = new OnClickListener() {
		public void onClick(View v) {
			// toggle benchmark in userClient
			if (mux != null && mux.userClient != null) {
				if (!mux.userClient.isBenchmarkOn()) {
					testcsm.setText("Stop Bench");
					logMsg("*** benchmark starting ***");
					mux.userClient.startBenchmark();
				} else {
					testcsm.setText("Start Bench");
					mux.userClient.stopBenchmark();
					logMsg("*** benchmark stopped ***");
				}
			}
			update();
		}
	};

	private OnClickListener left_listener = new OnClickListener() {
		public void onClick(View v) {
			if (directionButtonsEnabled) {
				RegionKey newRegion = new RegionKey(mux.vncDaemon.myRegion);
				newRegion.x--;
				mux.vncDaemon.changeRegion(newRegion);
			}
		}
	};
	private OnClickListener right_listener = new OnClickListener() {
		public void onClick(View v) {
			if (directionButtonsEnabled) {
				RegionKey newRegion = new RegionKey(mux.vncDaemon.myRegion);
				newRegion.x++;
				mux.vncDaemon.changeRegion(newRegion);
			}
		}
	};
	private OnClickListener up_listener = new OnClickListener() {
		public void onClick(View v) {
			if (directionButtonsEnabled) {
				RegionKey newRegion = new RegionKey(mux.vncDaemon.myRegion);
				newRegion.y++;
				mux.vncDaemon.changeRegion(newRegion);
			}
		}
	};
	private OnClickListener down_listener = new OnClickListener() {
		public void onClick(View v) {
			if (directionButtonsEnabled) {
				RegionKey newRegion = new RegionKey(mux.vncDaemon.myRegion);
				newRegion.y--;
				mux.vncDaemon.changeRegion(newRegion);
			}
		}
	};

	private OnClickListener cacheenable_listener = new OnClickListener() {
		public void onClick(View v) {
			mux.vncDaemon.enableCaching();
		}
	};

	private OnClickListener cachedisable_listener = new OnClickListener() {
		public void onClick(View v) {
			mux.vncDaemon.disableCaching();
		}
	};

	/***
	 * Location / GPS Stuff adapted from
	 * http://hejp.co.uk/android/android-gps-example/
	 */

	/** Called when a location update is received */
	@Override
	public void onLocationChanged(Location loc) {
		mux.vncDaemon.checkLocation(loc);
	}

	/** Bring up the GPS settings if/when the GPS is disabled. */
	@Override
	public void onProviderDisabled(String arg0) {
		// startActivity(new Intent(
		// android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
	}

	/** Called if/when the GPS is enabled in settings */
	@Override
	public void onProviderEnabled(String arg0) {
	}

	/** Called upon change in GPS status */
	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		switch (status) {
		case LocationProvider.OUT_OF_SERVICE:
			logMsg("GPS out of service");
			// TODO relinquish leadership if leading a region?
			break;
		case LocationProvider.TEMPORARILY_UNAVAILABLE:
			logMsg("GPS temporarily unavailable");
			// TODO relinquish leadership if leading a region?
			break;
		case LocationProvider.AVAILABLE:
			// nothing needs to be done...
			logMsg("GPS available");
			break;
		}
	}
}